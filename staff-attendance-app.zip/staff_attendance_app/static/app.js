let scanner=null;

function showTab(name){
  document.querySelectorAll(".tab").forEach(x=>x.classList.add("hidden"));
  document.getElementById(name).classList.remove("hidden");
  document.querySelectorAll(".tabs button").forEach(x=>x.classList.remove("active"));
  document.getElementById("tab-"+name).classList.add("active");
  if(name==="dashboard") loadAttendance();
  if(name==="admin") loadEmployees();
}
document.getElementById("date").value=new Date().toISOString().slice(0,10);

document.getElementById("startScan").onclick=async()=>{
  if(!window.Html5Qrcode){alert("QR scanner is still loading. Please try again.");return;}
  if(scanner){return;}
  scanner=new Html5Qrcode("reader");
  try{
    await scanner.start({facingMode:"environment"},{fps:10,qrbox:{width:250,height:250}},async text=>{
      await scanner.stop(); scanner.clear(); scanner=null;
      await doScan(text);
    },()=>{});
  }catch(e){
    scanner=null;
    alert("មិនអាចបើក Camera បានទេ។ សូមអនុញ្ញាត Camera permission និងប្រើ HTTPS.");
  }
};

async function doScan(code){
  const box=document.getElementById("scanResult");
  box.classList.remove("hidden");
  box.textContent="កំពុងកត់ត្រា...";
  try{
    const r=await fetch("/api/scan",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({employee_code:code})});
    const d=await r.json();
    if(!r.ok) throw new Error(d.detail||"Error");
    box.innerHTML=`<b>${d.action} ✅</b><br>${d.employee.name}<br>${d.date} ${d.time||""}<br>ស្ថានភាព: ${d.status}`;
  }catch(e){box.textContent="❌ "+e.message}
}

async function loadAttendance(){
  const date=document.getElementById("date").value;
  const r=await fetch("/api/attendance?date="+encodeURIComponent(date));
  const rows=await r.json();
  let p=0,l=0,a=0;
  document.getElementById("attendanceBody").innerHTML=rows.map(x=>{
    if(x.status==="Present")p++; else if(x.status==="Late")l++; else a++;
    const cls=x.status.toLowerCase();
    return `<tr><td>${x.employee_code}</td><td>${x.name}</td><td>${x.check_in||"-"}</td><td>${x.check_out||"-"}</td><td><span class="badge ${cls}">${x.status}</span></td></tr>`;
  }).join("");
  present.textContent=p;late.textContent=l;absent.textContent=a;
}
function exportCSV(){window.location="/api/export?date="+encodeURIComponent(date.value)}

document.getElementById("employeeForm").onsubmit=async e=>{
  e.preventDefault();
  const r=await fetch("/api/employees",{method:"POST",body:new FormData(e.target)});
  const d=await r.json();
  if(!r.ok){alert(d.detail||"Error");return}
  e.target.reset(); loadEmployees(); alert("បានបន្ថែមបុគ្គលិក: "+d.name);
};
async function loadEmployees(){
  const r=await fetch("/api/employees"); const rows=await r.json();
  document.getElementById("employees").innerHTML=rows.map(x=>`<div class="emp"><div><b>${x.name}</b><br><small>${x.employee_code} • ${x.position||"—"}</small></div><button class="danger" onclick="removeEmployee(${x.id})">លុប</button></div>`).join("")||"<p class='muted'>មិនទាន់មានបុគ្គលិក</p>";
}
async function removeEmployee(id){
  if(!confirm("លុបបុគ្គលិកនេះ?"))return;
  await fetch("/api/employees/"+id,{method:"DELETE"});loadEmployees();
}
loadAttendance();