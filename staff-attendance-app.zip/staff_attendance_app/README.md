# Staff Attendance App

QR-based staff attendance web app for iPhone and Android.

## Features
- QR scan from phone camera
- Check-in / Check-out
- Present / Late / Absent
- Employee management
- Daily attendance dashboard
- CSV/Excel-compatible export
- Responsive mobile UI
- FastAPI + SQLite

## Local run
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```
Open http://127.0.0.1:8000

## Render
Create a new Web Service from this repository.
- Build: `pip install -r requirements.txt`
- Start: `uvicorn main:app --host 0.0.0.0 --port $PORT`

Important: this starter uses SQLite. For production with persistent records, use a managed PostgreSQL database or a persistent disk. Render's normal ephemeral filesystem should not be treated as permanent database storage.

## First setup
1. Open the website.
2. Go to Admin.
3. Add employees with unique Employee IDs such as EMP001.
4. Put the Employee ID into each employee's QR code.
5. Employees scan their QR code at the attendance page.

The QR content only needs to be the employee code, e.g. `EMP001`.
